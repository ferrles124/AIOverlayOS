# J.A.R.V.I.S. — Android AI Assistant

Gerçek bir sesli AI asistan. Groq API ile çalışır, Türkçe anlar ve konuşur.

## Özellikler
- 🎙️ Sürekli sesli dinleme (SpeechRecognizer)
- 🔊 Türkçe sesli yanıt (TextToSpeech)
- 🤖 Groq llama-3.3-70b ile akıllı sohbet
- ⏰ Saat, tarih raporu
- 🌤️ Hava durumu (OpenWeatherMap)
- 🔋 Pil durumu
- 📝 Görev listesi (kalıcı)
- ⏰ Hatırlatıcı (bildirim)
- 📱 SMS taslak açma
- 🔄 Cihaz açılınca otomatik başlama

## Kurulum

### 1. Repo oluştur
GitHub'da yeni repo aç: `AIOverlay`
Tüm dosyaları yükle (klasör yapısını koru)

### 2. APK derle
- Repo'da **Actions** sekmesine git
- **Build JARVIS APK** workflow'u çalıştır
- Bittikten sonra **Artifacts** kısmından `JARVIS-APK` indir

### 3. Uygulamayı yükle
- İndirdiğin zip'i aç, `app-debug.apk` dosyasını al
- Android'de **Bilinmeyen kaynaklardan yükleme** iznini ver
- APK'yı yükle

### 4. API Keyleri al
**Groq API (ücretsiz):**
- https://console.groq.com → API Keys → Create

**OpenWeatherMap (opsiyonel, ücretsiz):**
- https://openweathermap.org/api → Free tier → API Key

### 5. Kullan
- Uygulamayı aç
- API keylerini gir, adını ve şehrini yaz
- **Ayarları Kaydet** → **JARVIS'İ Başlat**
- Konuş!

## Komutlar
| Komut | Açıklama |
|-------|----------|
| "Uyan" | Saat + hava + pil raporu |
| "Saat kaç?" | Saati söyler |
| "Hava durumu" | Hava bilgisi |
| "Pil durumu" | Batarya yüzdesi |
| "Görev ekle: matematik ödevi" | Görevi kaydeder |
| "Görevleri listele" | Tüm görevleri okur |
| "10 dakika sonra hatırlat: toplantı" | Bildirim gönderir |
| "Ahmet'e mesaj gönder: geç kalıyorum" | SMS uygulaması açar |
| Diğer her şey | Groq AI cevaplar |

## Notlar
- İnternet bağlantısı gerekli (Groq API için)
- Mikrofon izni şart
- Sesli tanıma için Google Speech Services gerekli (çoğu telefonda var)
